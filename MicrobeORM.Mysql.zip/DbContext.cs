using System;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Linq.Mapping;

using MySql.Data.MySqlClient;
using System.Transactions;


using MicrobeORM.Mysql.Utilities;
using MicrobeORM.Mysql.CommandTree;
using MicrobeORM.Mysql.PagerSQL;


namespace MicrobeORM.Mysql
{


    /// <summary>
    /// �������ݿ��  ������  ����ִ�������ݿ���н���
    /// </summary>
    public class DbContext<TElement> : SQLOperationCore, IDbContext<TElement>, IDisposable
        where TElement : BaseEntity, new()
    {
        #region Construction and fields


        private string _CurrentDBConnectionString;
        // ���ݿ������ַ���--���ǻ����е�����
        public override string CurrentDBConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(this._CurrentDBConnectionString))
                {
                    this._CurrentDBConnectionString = GlobalDBConnection.DefaultDBConnectionString;
                }
                return this._CurrentDBConnectionString;
            }
            set
            {
                this._CurrentDBConnectionString = value;
            }
        }

        /// <summary>
        /// ʵ�����������
        /// </summary>
        private const string EntityIdentityFiledName = "Id";

        private const string GetMaxIdentitySQLCMD = "SELECT IFNULL( MAX({0}) ,0) as MaxV FROM  {1};";

        /// <summary>
        /// Ĭ�����ݿ����ӱ�֤����Ϊ�գ�������
        /// </summary>
        protected DbContext()
        {
            Check.NotEmpty(GlobalDBConnection.DefaultDBConnectionString, "GlobalDBConnection.DefaultConnectionString");
        }
        public DbContext(string connString)
        {
            Check.NotEmpty(connString, "User Custom DBConnectionString Erorr,Please check it!");
            this._CurrentDBConnectionString = connString;
        }



        #endregion





        #region Context methods


        #region  Insert����
        /// <summary>
        /// ���� ʵ��
        /// </summary>
        /// <typeparam name="TElement"></typeparam>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int Insert(TElement entity)
        {
            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            ResolveEntity(entity, out tableInDbName, out propertys, out filelds, out paras);

            ///��������������
            var noIdentityPropertys = propertys.Remove(x => x.Name == EntityIdentityFiledName);
            var noIdentityFileds = filelds.Remove(x => x == EntityIdentityFiledName);
            var noIdentityParas = paras.Remove(x => x == string.Format("@{0}", EntityIdentityFiledName));

            var fieldSplitString = String.Join(",", noIdentityFileds);//���ض��ŷָ����ַ��� ���磺ProvinceCode,ProvinceName,Submmary
            var parasSplitString = String.Join(",", noIdentityParas);//����   ���� �Ķ��ŷָ�


            StringBuilder sb_Sql = new StringBuilder();
            sb_Sql.Append(string.Format("insert into {0}(", tableInDbName));
            sb_Sql.Append(string.Format("{0})", fieldSplitString));
            sb_Sql.Append(" values (");
            sb_Sql.Append(string.Format("{0})", parasSplitString));
            sb_Sql.Append(";select @@IDENTITY;");


            MySqlParameter[] parameters = new MySqlParameter[noIdentityParas.Length];

            for (int i = 0; i < noIdentityParas.Length; i++)
            {
                var para = new MySqlParameter(noIdentityParas[i], DbTypeAndCLRType.ConvertClrTypeToDbType(noIdentityPropertys[i].PropertyType));
                para.Value = noIdentityPropertys[i].GetValue(entity, null);
                para.IsNullable = true;

                parameters[i] = para;
            }

            //���ӣ����ϴ���  ��������Ĵ���
            //{
            //        new MySqlParameter("@ProvinceCode", MySqlDbType.NVarChar,15),
            //        new MySqlParameter("@ProvinceName", MySqlDbType.NVarChar,50),
            //        new MySqlParameter("@Submmary", MySqlDbType.Text)};
            //parameters[0].Value = model.ProvinceCode;
            //parameters[1].Value = model.ProvinceName;
            //parameters[2].Value = model.Submmary;

            var sqlCmd = sb_Sql.ToString();


            ///�������ַ���ƴ�ӹ���������Դ
            sb_Sql.Clear();
            sb_Sql = null;
            propertys = null;
            filelds = null;
            paras = null;
            noIdentityPropertys = null;
            noIdentityFileds = null;
            noIdentityParas = null;


            return ExecuteNonQuery(sqlCmd, CommandType.Text, parameters);
        }


        /// <summary>
        /// ����������β�����ʵ��
        /// </summary>
        /// <param name="entities"></param>
        public int InsertMulitiEntities(IEnumerable<TElement> entities)
        {
            //ע�⣺ SQL Server ������������ 2100 �������� ����ʹ�÷��������߼����ܽ���Щ����ֵ��ϵ�����������ʱ�����Խ��д�����
            var result = -1;


            var count_entities = entities.Count();
            if (count_entities <= 0)
            {
                return result;
            }


            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            ResolveEntity(entities.First(), out tableInDbName, out propertys, out filelds, out paras);

            ///��������������
            var noIdentityPropertys = propertys.Remove(x => x.Name == EntityIdentityFiledName);
            var noIdentityFileds = filelds.Remove(x => x == EntityIdentityFiledName);
            var noIdentityParas = paras.Remove(x => x == string.Format("@{0}", EntityIdentityFiledName));
            //�������һ������������--ԭʼ����
            var lastPara = noIdentityParas.Last();
            var paraCount = noIdentityParas.Length;

            var fieldSplitString = String.Join(",", noIdentityFileds);//���ض��ŷָ����ַ��� ���磺ProvinceCode,ProvinceName,Submmary
            //var parasSplitString = String.Join(",", noIdentityParas);//����   ���� �Ķ��ŷָ�

            var sqlBag = new StringBuilder();//����ʵ������SQL��� ��
            var sqlParasBag = new List<MySqlParameter>();//������Ҫ��SQL����

            StringBuilder sb_Sql = new StringBuilder();

            //��ȡ����ID  SQLָ��
            var cmdForGetMaxID = string.Format(GetMaxIdentitySQLCMD, EntityIdentityFiledName, tableInDbName);


            using (var tran = new TransactionScope(TransactionScopeOption.Required))
            {
                try
                {



                    var entityBags = entities.SplitToBatchBag();//��ʵ�� ��ֶ���   ����SQL������� 2100��


                    foreach (var bag in entityBags)
                    {
                        for (int i = 0; i < bag.Count(); i++)
                        {
                            var entity = bag.ElementAt(i);

                            var splitor = string.Format("{0},", i);//����ǰʵ������׷����Ϊ�����ָ��� ���磺@a0,@b0,@c0
                            //׷�����һ�������ı�ʶ���� ������@c0
                            var setLastPara = lastPara + i;
                            noIdentityParas[paraCount - 1] = setLastPara;//�滻���һ������

                            //���� "@a0,@b0,@c0"
                            var parasSplitString = String.Join(splitor, noIdentityParas);//����   ���� �Ķ��ŷָ�
                            var parasWithIndex = parasSplitString.Split(',');//���������Ĳ������� 

                            sb_Sql.Append(string.Format("insert into {0}(", tableInDbName));
                            sb_Sql.Append(string.Format("{0})", fieldSplitString));
                            sb_Sql.Append(" values (");
                            sb_Sql.Append(string.Format("{0})", parasSplitString));
                            sb_Sql.Append(";");

                            var sql = sb_Sql.ToString();
                            sb_Sql.Clear();

                            sqlBag.Append(sql);


                            MySqlParameter[] parameters = new MySqlParameter[parasWithIndex.Length];

                            for (int pos = 0; pos < parasWithIndex.Length; pos++)
                            {
                                var para = new MySqlParameter(parasWithIndex[pos], DbTypeAndCLRType.ConvertClrTypeToDbType(noIdentityPropertys[pos].GetType()));
                                para.Value = noIdentityPropertys[pos].GetValue(entity, null);
                                para.IsNullable = true;

                                parameters[pos] = para;
                            }

                            sqlParasBag.AddRange(parameters);
                        }

                        //sqlBag.Append("select @@IDENTITY");//�������ı�ʶID

                        sqlBag.Append(cmdForGetMaxID);//�������ı�ʶID


                        var sqlCmd = sqlBag.ToString();


                        result = Convert.ToInt32(ExecuteScalar(sqlCmd, CommandType.Text, sqlParasBag.ToArray()));

                        sqlBag.Clear();
                        sqlParasBag.Clear();
                    }

                    //ȫ����ȷִ��  ��ô�ύ����
                    tran.Complete();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    //������Դ
                    sqlParasBag.Clear();
                    sqlParasBag = null;
                    sqlBag.Clear();
                    sqlBag = null;
                    propertys = null;
                    filelds = null;
                    paras = null;
                    noIdentityPropertys = null;
                    noIdentityFileds = null;
                    noIdentityParas = null;

                }

            }

            return result;

            //using (var tran = new TransactionScope(TransactionScopeOption.Required))
            //{
            //    try
            //    {
            //        foreach (var item in entities)
            //        {
            //            Insert(item);
            //        }

            //        //ȫ����ȷִ��  ��ô�ύ����
            //        tran.Complete();
            //    }
            //    catch (Exception ex)
            //    {
            //        throw ex;
            //    }

            //}



        }

        #endregion


        #region Update ���²���
        /// <summary>
        /// ���µ���ģ��
        /// </summary>
        /// <typeparam name="TElement"></typeparam>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int Update(TElement entity)
        {
            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            ResolveEntity(entity, out tableInDbName, out propertys, out filelds, out paras);
            if (filelds.Length <= 1)
            {
                //�������� û�������ֶ�
                return -1;
                throw new Exception("δָ���������������ֶΣ�");
            }

            StringBuilder sb_FiledParaPairs = new StringBuilder("");
            for (int i = 0; i < filelds.Length; i++)
            {
                if (filelds[i] != EntityIdentityFiledName)
                {
                    sb_FiledParaPairs.AppendFormat("{0}=@{0},", filelds[i]);
                }
            }
            //�Ƴ����һ������
            var str_FiledParaPairs = sb_FiledParaPairs.ToString();
            str_FiledParaPairs = str_FiledParaPairs.Remove(str_FiledParaPairs.Length - 1);

            StringBuilder sb_Sql = new StringBuilder();
            sb_Sql.Append(string.Format("update {0} set ", tableInDbName));//Set Table
            sb_Sql.Append(str_FiledParaPairs);//������

            //sb_Sql.Append("ProvinceCode=@ProvinceCode,");
            //sb_Sql.Append("ProvinceName=@ProvinceName,");
            //sb_Sql.Append("Submmary=@Submmary");

            sb_Sql.AppendFormat(" where {0}=@{0}", EntityIdentityFiledName);//����

            //�趨����ֵ--------(�ֶ�һһӳ��)
            MySqlParameter[] parameters = new MySqlParameter[paras.Length];
            for (int i = 0; i < paras.Length; i++)
            {
                var Parameter = new MySqlParameter(paras[i], DbTypeAndCLRType.ConvertClrTypeToDbType(propertys[i].GetType()));
                Parameter.Value = propertys[i].GetValue(entity, null);
                Parameter.IsNullable = true;
                parameters[i] = Parameter;
            }

            //MySqlParameter[] parameters = {
            //        new MySqlParameter("@ProvinceCode", MySqlDbType.NVarChar,15),
            //        new MySqlParameter("@ProvinceName", MySqlDbType.NVarChar,50),
            //        new MySqlParameter("@Submmary", MySqlDbType.Text),
            //        new MySqlParameter("@ID", MySqlDbType.Int,4)};
            //parameters[0].Value = model.ProvinceCode;
            //parameters[1].Value = model.ProvinceName;
            //parameters[2].Value = model.Submmary;
            //parameters[3].Value = model.ID;

            var sqlCmd = sb_Sql.ToString();
            ///�������ַ���ƴ�ӹ���������Դ
            sb_FiledParaPairs.Clear();
            sb_FiledParaPairs = null;
            sb_Sql.Clear();
            sb_Sql = null;
            propertys = null;
            filelds = null;
            paras = null;


            return ExecuteNonQuery(sqlCmd, CommandType.Text, parameters);
        }

        /// <summary>
        /// ����Ԫ�� ͨ��  ����������
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="hopeUpdateColumns"></param>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public int UpdateByCondition(TElement entity, Fields<TElement> hopeUpdateColumns, Expression<Func<TElement, bool>> predicate)
        {
            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            ResolveEntity(entity, out tableInDbName, out propertys, out filelds, out paras);
            if (filelds.Length <= 1)
            {
                //�������� û�������ֶ�
                return -1;
                throw new Exception("δָ���������������ֶΣ�");
            }


            StringBuilder sb_FiledParaPairs = new StringBuilder("");
            ///����Ҫ���µ���
            for (int i = 0; i < hopeUpdateColumns.Container_Fileds.Count; i++)
            {
                if (hopeUpdateColumns.Container_Fileds[i] != EntityIdentityFiledName)
                {
                    sb_FiledParaPairs.AppendFormat("{0}=@{0},", hopeUpdateColumns.Container_Fileds[i]);
                }
            }
            //�Ƴ����һ������
            var str_FiledParaPairs = sb_FiledParaPairs.ToString();
            str_FiledParaPairs = str_FiledParaPairs.Remove(str_FiledParaPairs.Length - 1);

            StringBuilder sb_Sql = new StringBuilder();
            sb_Sql.Append(string.Format("update {0} set ", tableInDbName));//Set Table
            sb_Sql.Append(str_FiledParaPairs);//������



            //sb_Sql.Append("ProvinceCode=@ProvinceCode,");
            //sb_Sql.Append("ProvinceName=@ProvinceName,");
            //sb_Sql.Append("Submmary=@Submmary");

            if (null != predicate)
            {
                string where = ResolveLambdaTreeToCondition.ConvertLambdaToCondition<TElement>(predicate);
                sb_Sql.Append(" where ");//��������
                sb_Sql.Append(where);//�����д��в���=ֵ��  ƴ���ַ���
            }

            //�趨����ֵ
            MySqlParameter[] parameters = new MySqlParameter[hopeUpdateColumns.Container_Fileds.Count];
            for (int i = 0; i < hopeUpdateColumns.Container_Fileds.Count; i++)
            {
                //Ҫ���µ��� ��ֵ
                var fieldName = hopeUpdateColumns.Container_Fileds[i];
                var columnMapToProperty = propertys.FirstOrDefault(x => x.Name == fieldName);
                var paraName = "@" + hopeUpdateColumns.Container_Fileds[i];
                var Parameter = new MySqlParameter(paraName, DbTypeAndCLRType.ConvertClrTypeToDbType(columnMapToProperty.GetType()));
                Parameter.IsNullable = true;
                Parameter.Value = columnMapToProperty.GetValue(entity, null);
                parameters[i] = Parameter;
            }

            //MySqlParameter[] parameters = {
            //        new MySqlParameter("@ProvinceCode", MySqlDbType.NVarChar,15),
            //        new MySqlParameter("@ProvinceName", MySqlDbType.NVarChar,50),
            //        new MySqlParameter("@Submmary", MySqlDbType.Text),
            //        new MySqlParameter("@ID", MySqlDbType.Int,4)};
            //parameters[0].Value = model.ProvinceCode;
            //parameters[1].Value = model.ProvinceName;
            //parameters[2].Value = model.Submmary;
            //parameters[3].Value = model.ID;

            var sqlCmd = sb_Sql.ToString();

            ///�����ַ�������
            sb_FiledParaPairs.Clear();
            sb_FiledParaPairs = null;
            sb_Sql.Clear();
            sb_Sql = null;
            propertys = null;
            filelds = null;
            paras = null;


            return ExecuteNonQuery(sqlCmd, CommandType.Text, parameters);
        }

        #endregion


        #region Select   ��ѯ����

        /// <summary>
        /// ͨ��������ȡ����Ԫ��
        /// </summary>
        /// <param name="id">Identifier</param>
        /// <returns>Entity</returns>
        public TElement GetElementById(int id)
        {

            TElement entity = new TElement();

            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            ResolveEntity(entity, out tableInDbName, out propertys, out filelds, out paras);
            if (filelds.Length <= 1)
            {
                //�������� û�������ֶ�
                return null;
                throw new Exception("δָ���������������ֶΣ�");
            }
            var fieldSplitString = String.Join(",", filelds);//���ض��ŷָ����ַ��� ���磺ProvinceCode,ProvinceName,Submmary

            StringBuilder sb_Sql = new StringBuilder();
            sb_Sql.AppendFormat("select  {0} ", fieldSplitString);
            sb_Sql.AppendFormat(" from {0} ", tableInDbName);//WITH (NOLOCK) ���ڲ�������ִ�е�������-�����������
            sb_Sql.Append(" where Id=@Id limit 1;");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@Id", MySqlDbType.Int32,4)
            };
            parameters[0].Value = id;

            var sqlCmd = sb_Sql.ToString();


            var reader = ExecuteReader(sqlCmd, CommandType.Text, parameters);
            reader.Read();
            entity = reader.ConvertDataReaderToEntity<TElement>();
            //�ͷŶ�ȡ�� ����Դ
            reader.Dispose();
            sb_Sql.Clear();
            sb_Sql = null;
            propertys = null;
            filelds = null;
            paras = null;


            return entity;
        }

        /// <summary>
        /// ͨ���ض���������ѯ��Ԫ�ؼ���
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public List<TElement> GetElementsByCondition(Expression<Func<TElement, bool>> predicate)
        {

            //����DataReader  ��ȡ���ݼ���
            List<TElement> dataLst = new List<TElement>();
            TElement entity = new TElement();

            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            StringBuilder sb_Sql = null;




            ResolveEntity(entity, out tableInDbName, out propertys, out filelds, out paras);
            if (filelds.Length <= 1)
            {
                //�������� û�������ֶ�
                return null;
                throw new Exception("δָ���������������ֶΣ�");
            }
            //��ȡ�ֶ�
            var fieldSplitString = String.Join(",", filelds);//���ض��ŷָ����ַ��� ���磺ProvinceCode,ProvinceName,Submmary
                                                             //������ѯ����
            var whereStr = ResolveLambdaTreeToCondition.ConvertLambdaToCondition<TElement>(predicate);


            sb_Sql = new StringBuilder();
            sb_Sql.AppendFormat("select  {0} ", fieldSplitString);
            sb_Sql.AppendFormat(" from {0} ", tableInDbName);
            sb_Sql.AppendFormat(" where {0};", whereStr);


            var sqlCmd = sb_Sql.ToString();



            try
            {

                var reader = ExecuteReader(sqlCmd, CommandType.Text, null);
                if (null == reader)
                {
                    return null;
                }



                while (reader.Read())
                {
                    var model = reader.ConvertDataReaderToEntity<TElement>();
                    dataLst.Add(model);
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                // �ͷ���Դ
                sb_Sql.Clear();
                sb_Sql = null;
                propertys = null;
                filelds = null;
                paras = null;
            }


            return dataLst;
        }

        /// <summary>
        /// ��ҳ��ȡԪ�ؼ���
        /// </summary>
        /// <param name="pageIndex">ҳ����</param>
        /// <param name="pageSize">ҳ��С</param>
        /// <param name="totalRecords">�ܼ�¼��</param>
        /// <param name="totalPages">��ҳ��</param>
        /// <param name="predicate">����</param>
        /// <param name="sortField">�����ֶ�</param>
        /// <param name="rule">�������</param>
        /// <returns></returns>
        public List<TElement> GetElementsByPagerAndCondition(int pageIndex, int pageSize, out int totalRecords, out int totalPages, Expression<Func<TElement, bool>> predicate, Fields<TElement> sortField, OrderRule rule = OrderRule.ASC)
        {
            TElement entity = new TElement();




            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            ResolveEntity(entity, out tableInDbName, out propertys, out filelds, out paras);
            if (filelds.Length <= 1)
            {
                //�������� û�������ֶ�
                totalRecords = -1;
                totalPages = -1;
                return null;
                throw new Exception("δָ���������������ֶΣ�");
            }
            //��ȡ�ֶ�
            var fieldSplitString = String.Join(",", filelds);//���ض��ŷָ����ַ��� ���磺ProvinceCode,ProvinceName,Submmary
            //������ѯ����
            var whereStr = "";
            if (null != predicate)
            {
                whereStr = ResolveLambdaTreeToCondition.ConvertLambdaToCondition<TElement>(predicate);
            }


            //���÷�ҳ�洢����
            StringBuilder sb_Sql = new StringBuilder();
            sb_Sql.Append(PagerSQLProcedure.PageSql_Call_Name);


            MySqlParameter[] parameters = {
                    new MySqlParameter("@PageIndex",MySqlDbType.Int32,4 ),//ҳ����
                    new MySqlParameter("@PageSize", MySqlDbType.Int32,4),//ҳ��С
                    new MySqlParameter("@TableName", MySqlDbType.VarChar,2000),//������
                    new MySqlParameter("@SelectFields", MySqlDbType.Text),//��ѯ���ֶ�
                    new MySqlParameter("@PrimaryKey", MySqlDbType.VarChar,50),//��ѯ�ı�������
                     new MySqlParameter("@ConditionWhere", MySqlDbType.Text), //��ѯ����      
                    new MySqlParameter("@SortField", MySqlDbType.VarChar,50),//�����ֶ�
                    new MySqlParameter("@IsDesc", MySqlDbType.Int32,4),//������ ������
                    new MySqlParameter("@TotalRecords", MySqlDbType.Int32,4),//�ܼ�¼������ѡ������
                    new MySqlParameter("@TotalPageCount", MySqlDbType.Int32,4)//��ҳ�������������
                                        };
            parameters[0].Value = pageIndex;
            parameters[1].Value = pageSize;
            parameters[2].Value = tableInDbName;
            parameters[3].Value = fieldSplitString;
            parameters[4].Value = EntityIdentityFiledName;
            parameters[5].Value = whereStr;
            parameters[6].Value = String.Join(",", sortField.Container_Fileds.ToArray());
            parameters[7].Value = rule == OrderRule.ASC ? 0 : 1;
            // parameters[8].Value = TotalRecords;
            parameters[8].Direction = ParameterDirection.Output;
            // parameters[9].Value = TotalPageCount;
            parameters[9].Direction = ParameterDirection.Output;
            var sql = sb_Sql.ToString();
            //�����ַ�������
            sb_Sql.Clear();
            sb_Sql = null;
            propertys = null;
            filelds = null;
            paras = null;

            try
            {
                var lst_PagedData = ExecuteStoredProcedureList(sql, parameters);
                //��ѯ��Ϻ� ����������� �����ܼ�¼�� ��ҳ��
                totalRecords = Convert.ToInt32(parameters[8].Value);
                totalPages = Convert.ToInt32(parameters[9].Value);

                return lst_PagedData;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }


        #endregion


        #region Delete ɾ������

        /// <summary>
        /// ɾ��һ��ʵ��
        /// </summary>
        /// <param name="@"></param>
        /// <returns></returns>
        public int Delete(TElement entity)
        {
            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            ResolveEntity(entity, out tableInDbName, out propertys, out filelds, out paras);
            if (filelds.Length <= 1)
            {
                //�������� û�������ֶ�
                return -1;
                throw new Exception("δָ���������������ֶΣ�");
            }



            StringBuilder sb_Sql = new StringBuilder();
            sb_Sql.AppendFormat("delete from {0} ", tableInDbName);
            sb_Sql.Append(" where Id=@Id;");
            MySqlParameter[] parameters = {
                    new MySqlParameter("@Id", MySqlDbType.Int32,4)
            };
            parameters[0].Value = entity.Id;

            var sqlCmd = sb_Sql.ToString();
            //����������
            sb_Sql.Clear();
            sb_Sql = null;
            propertys = null;
            filelds = null;
            paras = null;

            try
            {
                return Convert.ToInt32(ExecuteNonQuery(sqlCmd, CommandType.Text, parameters));

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// ɾ������������ʵ��
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public int DeleteByCondition(Expression<Func<TElement, bool>> predicate)
        {
            TElement entity = new TElement();


            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            ResolveEntity(entity, out tableInDbName, out propertys, out filelds, out paras);
            if (filelds.Length <= 1)
            {
                //�������� û�������ֶ�
                return -1;
                throw new Exception("δָ���������������ֶΣ�");
            }

            //������ѯ����
            var whereStr = "";
            if (null != predicate)
            {

                whereStr = ResolveLambdaTreeToCondition.ConvertLambdaToCondition<TElement>(predicate);

            }


            StringBuilder sb_Sql = new StringBuilder();
            sb_Sql.AppendFormat("delete from {0} ", tableInDbName);
            if (null != predicate)
            {
                sb_Sql.AppendFormat("where  {0}  ;", whereStr);
            }



            var sqlCmd = sb_Sql.ToString();
            try
            {
                return Convert.ToInt32(ExecuteNonQuery(sqlCmd, CommandType.Text));

            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                //����������
                sb_Sql.Clear();
                sb_Sql = null;
                propertys = null;
                filelds = null;
                paras = null;
            }


        }



        #endregion


        #region  �ۺϺ���ʵ��  SUM COUNT  MAX  MIN

        /// <summary>
        /// ʹ��ָ�������� ������
        /// </summary>
        /// <param name="predicate"></param>
        /// <param name="specialColumn"></param>
        /// <returns></returns>
        public int Sum(Expression<Func<TElement, bool>> predicate, Fields<TElement> specialColumn)
        {
            TElement entity = new TElement();


            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            ResolveEntity(entity, out tableInDbName, out propertys, out filelds, out paras);
            if (filelds.Length <= 1)
            {
                //�������� û�������ֶ�
                throw new Exception("δָ���������������ֶΣ�");
            }

            //������ѯ����
            var whereStr = ResolveLambdaTreeToCondition.ConvertLambdaToCondition<TElement>(predicate);


            StringBuilder sb_Sql = new StringBuilder();
            sb_Sql.AppendFormat("SELECT SUM({0}) FROM  {1} ", specialColumn.Container_Fileds.FirstOrDefault(), tableInDbName);
            if (!string.IsNullOrEmpty(whereStr))
            {
                sb_Sql.AppendFormat("WHERE {0} ", whereStr);
            }


            var sqlCmd = sb_Sql.ToString();

            //�����ַ�������
            sb_Sql.Clear();
            sb_Sql = null;
            propertys = null;
            filelds = null;
            paras = null;
            try
            {
                return Convert.ToInt32(ExecuteScalar(sqlCmd, CommandType.Text));

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        /// <summary>
        /// ͳ�� ��������������
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public int Count(Expression<Func<TElement, bool>> predicate)
        {
            TElement entity = new TElement();


            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            ResolveEntity(entity, out tableInDbName, out propertys, out filelds, out paras);
            if (filelds.Length <= 1)
            {
                //�������� û�������ֶ�
                throw new Exception("δָ���������������ֶΣ�");
            }

            //������ѯ����
            var whereStr = ResolveLambdaTreeToCondition.ConvertLambdaToCondition<TElement>(predicate);


            StringBuilder sb_Sql = new StringBuilder();
            sb_Sql.AppendFormat("SELECT COUNT(0) FROM  {0} ", tableInDbName);
            if (!string.IsNullOrEmpty(whereStr))
            {
                sb_Sql.AppendFormat("WHERE {0} ", whereStr);
            }

            var sqlCmd = sb_Sql.ToString();

            //�����ַ�������
            sb_Sql.Clear();
            sb_Sql = null;
            propertys = null;
            filelds = null;
            paras = null;
            try
            {
                return Convert.ToInt32(ExecuteScalar(sqlCmd, CommandType.Text));

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        /// <summary>
        /// �����������е� ָ���е����ֵ
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="selector"></param>
        /// <returns></returns>
        public int Max(Expression<Func<TElement, bool>> predicate, Fields<TElement> specialColumn)
        {
            TElement entity = new TElement();


            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            ResolveEntity(entity, out tableInDbName, out propertys, out filelds, out paras);
            if (filelds.Length <= 1)
            {
                //�������� û�������ֶ�
                throw new Exception("δָ���������������ֶΣ�");
            }

            //������ѯ����
            var whereStr = ResolveLambdaTreeToCondition.ConvertLambdaToCondition<TElement>(predicate);


            StringBuilder sb_Sql = new StringBuilder();
            sb_Sql.AppendFormat("SELECT MAX({0}) FROM  {1} ", specialColumn.Container_Fileds.FirstOrDefault(), tableInDbName);
            if (!string.IsNullOrEmpty(whereStr))
            {
                sb_Sql.AppendFormat("WHERE {0} ", whereStr);
            }

            var sqlCmd = sb_Sql.ToString();

            //�����ַ�������
            sb_Sql.Clear();
            sb_Sql = null;
            propertys = null;
            filelds = null;
            paras = null;
            try
            {
                return Convert.ToInt32(ExecuteScalar(sqlCmd, CommandType.Text));

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        /// <summary>
        /// �����������е� ָ���е���Сֵ
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="predicate"></param>
        /// <param name="specialColumn"></param>
        /// <returns></returns>
        public int Min(Expression<Func<TElement, bool>> predicate, Fields<TElement> specialColumn)
        {
            TElement entity = new TElement();


            string tableInDbName;
            System.Reflection.PropertyInfo[] propertys;
            string[] filelds;
            string[] paras;
            ResolveEntity(entity, out tableInDbName, out propertys, out filelds, out paras);
            if (filelds.Length <= 1)
            {
                //�������� û�������ֶ�
                throw new Exception("δָ���������������ֶΣ�");
            }

            //������ѯ����
            var whereStr = ResolveLambdaTreeToCondition.ConvertLambdaToCondition<TElement>(predicate);


            StringBuilder sb_Sql = new StringBuilder();
            sb_Sql.AppendFormat("SELECT MIN({0}) FROM  {1} ", specialColumn.Container_Fileds.FirstOrDefault(), tableInDbName);
            if (!string.IsNullOrEmpty(whereStr))
            {
                sb_Sql.AppendFormat("WHERE {0} ", whereStr);
            }

            var sqlCmd = sb_Sql.ToString();

            //�����ַ�������
            sb_Sql.Clear();
            sb_Sql = null;
            propertys = null;
            filelds = null;
            paras = null;
            try
            {
                return Convert.ToInt32(ExecuteScalar(sqlCmd, CommandType.Text));

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        #endregion


        /// <summary>
        /// ִ��һ��SQL��ѯ��䣬���в�������ѯ
        /// </summary>
        /// <typeparam name="TEntity">Entity type</typeparam>
        /// <param name="commandText">Command text</param>
        /// <param name="parameters">Parameters</param>
        /// <returns>Entities</returns>
        public List<TElement> SqlQuery(string commandText, params MySqlParameter[] parameters)
        {


            //��ȡ���صĽ�� ��ΪDataTable  �������е�Row ���ض���ʵ��
            DataTable dt = new DataTable();
            this.FillTheDataTableBySql(commandText, CommandType.Text, ref dt, parameters);


            var results = dt.ConvertDataTableToEntitys<TElement>();
            dt.Clear();
            dt.Dispose();
            return results;
        }


        /// <summary>
        /// Execute stores procedure and load a list of entities at the end
        /// </summary>
        /// <typeparam name="TEntity">Entity type</typeparam>
        /// <param name="commandText">Command text</param>
        /// <param name="parameters">Parameters</param>
        /// <returns>Entities</returns>
        public List<TElement> ExecuteStoredProcedureList(string commandText, params MySqlParameter[] parameters)
        {


            //��ȡ���صĽ�� ��ΪDataTable  �������е�Row ���ض���ʵ��
            DataTable dt = new DataTable();
            this.FillTheDataTableBySql(commandText, CommandType.StoredProcedure, ref dt, parameters);


            var results = dt.ConvertDataTableToEntitys<TElement>();
            dt.Clear();
            dt.Dispose();
            return results;
        }




        #endregion





        #region Other Methods
        /// <summary>
        /// ����ʵ��   �������еĹ����ı�+�ֶ�+�ֶβ���
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="tableInDbName"></param>
        /// <param name="propertys"></param>
        /// <param name="filelds"></param>
        /// <param name="paras"></param>
        private static void ResolveEntity(TElement entity, out string tableInDbName, out System.Reflection.PropertyInfo[] propertys, out string[] filelds, out string[] paras)
        {
            tableInDbName = "";
            var targetAttributes = entity.GetType().GetCustomAttributes(typeof(TableAttribute), false);
            if (null == targetAttributes)
            {
                throw new Exception("the model class has not mapping table!");
            }
            tableInDbName = (targetAttributes[0] as TableAttribute).Name;

            //��ȡ�����ֶ�
            propertys = entity.GetCurrentEntityProperties();//entity.CurrentModelPropertys;// entity.GetType().GetProperties();
            filelds = new string[propertys.Length];
            for (int i = 0; i < propertys.Length; i++)
            {
                filelds[i] = propertys[i].Name;
            }
            //�����ֶ�
            paras = filelds.Clone() as string[];
            for (int i = 0; i < paras.Length; i++)
            {
                paras[i] = "@" + paras[i];
            }
        }

        #endregion


        #region Disposable


        //�Ƿ�������
        bool _disposed;
        public void Dispose()
        {

            //�ÿ������ַ���
            this.CurrentDBConnectionString = null;
            Dispose(true);
            // This class has no unmanaged resources but it is possible that somebody could add some in a subclass.
            GC.SuppressFinalize(this);

        }
        //����Ĳ�����ʾʾ�Ƿ���Ҫ�ͷ���Щʵ��IDisposable�ӿڵ��йܶ���
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed) return; //����Ѿ������գ����ж�ִ��
            if (disposing)
            {
                //TODO:�ͷ���Щʵ��IDisposable�ӿڵ��йܶ���

            }
            //TODO:�ͷŷ��й���Դ�����ö���Ϊnull
            _disposed = true;
        }


        #endregion




    }
}
