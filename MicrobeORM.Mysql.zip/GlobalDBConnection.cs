﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

using MicrobeORM.Mysql.Utilities;
using MicrobeORM.Mysql.PagerSQL;

namespace MicrobeORM.Mysql
{
    /// <summary>
    /// 使用此全局数据库连接字符串定义与数据库进行交互 的数据连接，
    /// 在整个应用程序生命周期都使用此配置表中的连接字符串
    /// 支持多个数据库的配置（key value）
    /// </summary>
    public class GlobalDBConnection
    {


        public static DbState DataBaseState { get; set; }
        public static IList<KeyValuePair<string, string>> ApplicationConnectionStrings { get; set; }

        /// <summary>
        /// 静态构造函数
        /// </summary>
        static GlobalDBConnection()
        {
            DataBaseState = DbState.Closed;
            ApplicationConnectionStrings = new List<KeyValuePair<string, string>>();

        }

        //定义基于 字符串 name形式的  索引器
        //索引器必须以this关键字定义，其实这个this就是类实例化之后的对象
        public string this[string connStringName]
        {
            get
            {
                string result = null;
                var pair = ApplicationConnectionStrings.FirstOrDefault(x => x.Key == connStringName);
                if (default(KeyValuePair<string, string>).Equals(pair))
                {
                    return null;
                }
                result = pair.Value;
                return result;
            }
            set
            {
                //设置的时候，不存在就插入个新的，存的话 更新，这个操作在程序中，操作频率不会太高
                var pair = ApplicationConnectionStrings.FirstOrDefault(x => x.Key == connStringName);
                var createPair = new KeyValuePair<string, string>(connStringName, value);
                if (default(KeyValuePair<string, string>).Equals(pair))
                {
                  
                    ApplicationConnectionStrings.Add(createPair);
                    return;
                }
                else
                {
                    ApplicationConnectionStrings.Remove(pair);
                    ApplicationConnectionStrings.Add(createPair);
                    return;

                }
            }

        }


        public static void LoadAndInitDatabase()
        {
            try
            {
                //加载配置文件中的 数据库连接字符串集合
                var allConnStrings = System.Configuration.ConfigurationManager.ConnectionStrings;
                if (null != allConnStrings && allConnStrings.Count > 0)
                {
                    foreach (ConnectionStringSettings item in allConnStrings)
                    {
                        var pair = new KeyValuePair<string, string>(item.Name, item.ConnectionString);

                        ApplicationConnectionStrings.Add(pair);

                        //设置好连接字符串后  初始化数据库  
                        InitDataBase(item.ConnectionString);


                    }
                }

                DataBaseState = DbState.Opened;//设定数据库均已经初始化完毕，并且是可打开的
            }
            catch (Exception ex)
            {
                DataBaseState = DbState.NotAllReady;//设定数据库未能完整设置完毕和open

                throw ex;
            }



        }


        /// <summary>
        /// 默认首个数据库连接字符串--数据库连接字符串
        /// </summary>
        public static string DefaultDBConnectionString
        {
            get
            {
                if (ApplicationConnectionStrings.Count <= 0)
                {
                    return null;
                }
                return ApplicationConnectionStrings[0].Value;
            }

        }



        private static void InitDataBase(string connStr)
        {
            try
            {

                //1 创建必须的分页存储过程等全局操作
                PagerSQLProcedure.CheckAndCreatePagerSQLProcedure(connStr);
                //2 Other Need Initial Operations....

            }
            catch (Exception ex)
            {
                DataBaseState = DbState.NotAllReady;//设定数据库未能完整设置完毕和open
                throw ex;
            }



        }
    }
}
