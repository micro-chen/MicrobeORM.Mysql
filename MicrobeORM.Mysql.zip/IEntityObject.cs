﻿using System;

namespace MicrobeORM.Mysql
{
    /// <summary>
    /// 所有业务实体对象的基础接口
    /// </summary>
    public interface IEntityObject
    {
        /// <summary>
        /// 业务实体 均需要一个自增类型的Id,此属性对应表中的自增Id列
        /// 此属性不能是只读属性，因为在实体的实例化后 ，我们需要给这个属性赋值
        /// 将从数据库读取出来的记录行，列，转化为对应的属性的值
        /// </summary>
        int Id { get; set;}
    }
}
