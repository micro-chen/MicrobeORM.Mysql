﻿
using System;
using System.Configuration;


namespace MicrobeORM.Mysql
{
    /// <summary>
    /// 设置数据库连接
    /// 包含多个数据库的连接字符串
    /// </summary>
    public class InitDatabase
    {
        public static void SetDatabaseConnection()
        {
            GlobalDBConnection.LoadAndInitDatabase();
        }
    }
}