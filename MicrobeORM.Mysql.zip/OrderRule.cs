﻿namespace MicrobeORM.Mysql
{
    public enum OrderRule
    {
        /// <summary>
        /// 正序
        /// </summary>
        ASC,
        /// <summary>
        /// 倒序
        /// </summary>
        DESC
    }
}
