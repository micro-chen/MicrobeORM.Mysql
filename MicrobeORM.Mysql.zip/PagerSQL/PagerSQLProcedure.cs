﻿using System;
using MySql.Data.MySqlClient;

namespace MicrobeORM.Mysql.PagerSQL
{

    /// <summary>
    /// 检测是否存在需要的分页存储过程
    /// </summary>
    public static class PagerSQLProcedure
    {

        internal static string PageSql_Call_Name = "MicrobeORM_Mysql_GetRecordsByPage";//调用入口



        internal static void CheckAndCreatePagerSQLProcedure(string connStr)
        {
            //1检查数据库是否存在存储过程   //2创建
            //分页调用入口

            CreateSQLProcedure(connStr,PageSql_Call_MySqlCommand);

        }


        private static void CreateSQLProcedure(string connStr,string MySqlCommand)
        {
            if (string.IsNullOrEmpty(connStr))
            {
                throw new Exception("数据库连接异常，请检查连接字符串的配置！");
            }



            using (var conn = new MySqlConnection(connStr))
            {
                if (conn.State != System.Data.ConnectionState.Open)
                {
                    conn.Open();
                }
                MySqlScript cmdScript = new MySqlScript(conn);
                cmdScript.Query = MySqlCommand;
                cmdScript.Delimiter = "??";//设定结束符

                int result= cmdScript.Execute();
            }
        }

        #region mysql  分页存储过程

        //调用入口sql存储过程
        private static string PageSql_Call_MySqlCommand = @"DROP PROCEDURE  IF EXISTS `MicrobeORM_Mysql_GetRecordsByPage`??

                            CREATE PROCEDURE MicrobeORM_Mysql_GetRecordsByPage(
                                PageIndex INT,  #查询页码  
                                PageSize INT,   #每页记录数 
                                TableName varchar(4000),  #要查询的表  
                                SelectFields  VARCHAR(1000), #要查询的字段，用逗号(,)分隔   
                                PrimaryKey  varchar(200),#主键
                                ConditionWhere VARCHAR(2000),   #查询条件  
                                SortField VARCHAR(200),  #排序规则
                                IsDesc INT,#0升序 1降序  
  
                                #输出参数  
                                OUT TotalRecords INT,  #总记录数  
                                OUT TotalPageCount INT    #总页数  
                                )
                            BEGIN
                             #140529-xxj-分页存储过程  
                                #计算起始行号  
                                SET @startRow = PageSize * (PageIndex - 1);  
                                SET @pageSize = PageSize;  
                                SET @rowindex = 0; #行号  
  
                                #合并字符串  
                                SET @strsql = CONCAT(  
                                    #'select sql_calc_found_rows  @rowindex:=@rowindex+1 as rownumber,' #记录行号  
                                    'select sql_calc_found_rows '  
                                    ,SelectFields   
                                    ,' from '  
                                    ,TableName  
                                    ,CASE IFNULL(ConditionWhere, '') WHEN '' THEN '' ELSE CONCAT(' where ', ConditionWhere) END  
                                    ,CASE IFNULL(SortField, '') WHEN '' THEN CONCAT(' order by ', PrimaryKey) ELSE CONCAT(' order by ', SortField) END  
                                    ,case IsDesc when 0 then concat(' ASC') else(' DESC') end
                                  ,' limit '   
                                    ,@startRow  
                                    ,','   
                                    ,@pageSize  
                                );  
  
                                PREPARE strsql FROM @strsql;#定义预处理语句   
                                EXECUTE strsql;                         #执行预处理语句   
                                DEALLOCATE PREPARE strsql;  #删除定义   
                                #通过 sql_calc_found_rows 记录没有使用 limit 语句的记录，使用 found_rows() 获取行数  
                                SET TotalRecords = FOUND_ROWS();  
  
                                #计算总页数  
                                IF (TotalRecords <= PageSize) THEN  
                                    SET TotalPageCount = 1;  
                                ELSE IF (TotalRecords % PageSize > 0) THEN  
                                    SET TotalPageCount = TotalRecords div PageSize+1;  
                                ELSE  
                                    SET TotalPageCount = TotalRecords div PageSize;  
                                END IF;  
                                END IF;  
  
                                END??
";

#endregion

    }
}
