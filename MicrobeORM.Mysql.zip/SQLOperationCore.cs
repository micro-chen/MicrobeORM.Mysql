﻿using System;
using System.Collections.Generic;
using System.Data;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Linq;
using System.Text;

namespace MicrobeORM.Mysql
{
    /// <summary>
    /// MYSQL 核心交互方法
    /// </summary>
    public  class SQLOperationCore
    {

        /// <summary>
        /// 数据库连接字符串-虚属性
        /// </summary>
        public virtual string CurrentDBConnectionString { get; set; }




        #region  SQL辅助相关
        /// <summary>
        /// Execute a MySqlCommand (that returns no resultset) against the database specified in the connection string 
        /// using the provided parameters.
        /// </summary>
        /// <remarks>
        /// e.g.:  
        ///  int result = ExecuteNonQuery(connString, CommandType.StoredProcedure, "PublishOrders", new MySqlParameter("@prodid", 24));
        /// </remarks>
        /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">the stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
        /// <returns>an int representing the number of rows affected by the command</returns>
        public int ExecuteNonQuery(string cmdText, CommandType cmdType, params MySqlParameter[] commandParameters)
        {



            using (MySqlConnection conn = new MySqlConnection(this.CurrentDBConnectionString))
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }
                using (MySqlCommand cmd = new MySqlCommand())
                {

                    var tran = conn.BeginTransaction();
                    int val = -1;
                    try
                    {
                        PrepareCommand(cmd, conn, tran, cmdType, cmdText, commandParameters);
                        val = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();

                        tran.Commit();//提交事务
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();//回滚事务
                        throw ex;
                    }

                    tran.Dispose();

                    return val;
                }

            }
        }





        /// <summary>
        /// Execute a MySqlCommand that returns a resultset against the database specified in the connection string 
        /// using the provided parameters.
        /// </summary>
        /// <remarks>
        /// e.g.:  
        ///  MySqlDataReader r = ExecuteReader(connString, CommandType.StoredProcedure, "PublishOrders", new MySqlParameter("@prodid", 24));
        /// </remarks>
        /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">the stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
        /// <returns>A MySqlDataReader containing the results</returns>
        protected MySqlDataReader ExecuteReader(string cmdText, CommandType cmdType, params MySqlParameter[] commandParameters)
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection conn = new MySqlConnection(this.CurrentDBConnectionString);
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            // we use a try/catch here because if the method throws an exception we want to 
            // close the connection throw code, because no datareader will exist, hence the 
            // commandBehaviour.CloseConnection will not work
            try
            {
                PrepareCommand(cmd, conn, null, cmdType, cmdText, commandParameters);
                MySqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                cmd.Parameters.Clear();
                return rdr;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
            }


        }

        /// <summary>
        /// Execute a MySqlCommand that returns the first column of the first record against the database specified in the connection string 
        /// using the provided parameters.
        /// </summary>
        /// <remarks>
        /// e.g.:  
        ///  Object obj = ExecuteScalar(connString, CommandType.StoredProcedure, "PublishOrders", new MySqlParameter("@prodid", 24));
        /// </remarks>
        /// <param name="connectionString">a valid connection string for a MySqlConnection</param>
        /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">the stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
        /// <returns>An object that should be converted to the expected type using Convert.To{Type}</returns>
        protected object ExecuteScalar(string cmdText, CommandType cmdType, params MySqlParameter[] commandParameters)
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connection = new MySqlConnection(this.CurrentDBConnectionString);
            if (connection.State != ConnectionState.Open)
            {
                connection.Open();
            }


            object val = null;
            try
            {
                PrepareCommand(cmd, connection,null, cmdType, cmdText, commandParameters);
                val = cmd.ExecuteScalar();
                cmd.Parameters.Clear();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
                connection.Dispose();
            }

            return val;

        }


        /// <summary>
        /// 填充一个数据集合
        /// </summary>
        /// <param name="cmdText"></param>
        /// <param name="cmdType"></param>
        /// <param name="ds"></param>
        /// <param name="commandParameters"></param>
        protected void FillTheDataSetBySql(string cmdText, CommandType cmdType, ref DataSet ds, params MySqlParameter[] commandParameters)
        {
            using (MySqlConnection connection = new MySqlConnection(this.CurrentDBConnectionString))
            {
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    PrepareCommand(cmd, connection, null, cmdType, cmdText, commandParameters);

                    var adapter = new MySqlDataAdapter(cmd);

                    adapter.Fill(ds);


                    cmd.Parameters.Clear();

                }

            }
        }

        /// <summary>
        /// 填充一个数据Table
        /// </summary>
        /// <param name="cmdText"></param>
        /// <param name="cmdType"></param>
        /// <param name="ds"></param>
        /// <param name="commandParameters"></param>
        protected void FillTheDataTableBySql(string cmdText, CommandType cmdType, ref DataTable dt, params MySqlParameter[] commandParameters)
        {
            using (MySqlConnection connection = new MySqlConnection(this.CurrentDBConnectionString))
            {
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    PrepareCommand(cmd, connection, null, cmdType, cmdText, commandParameters);

                    var adapter = new MySqlDataAdapter(cmd);

                    adapter.Fill(dt);


                    cmd.Parameters.Clear();

                }

            }
        }

        /// <summary>
        /// Prepare a command for execution
        /// </summary>
        /// <param name="cmd">MySqlCommand object</param>
        /// <param name="conn">MySqlConnection object</param>
        /// <param name="trans">MySqlTransaction object</param>
        /// <param name="cmdType">Cmd type e.g. stored procedure or text</param>
        /// <param name="cmdText">Command text, e.g. Select * from Products</param>
        /// <param name="cmdParms">MySqlParameters to use in the command</param>
        private void PrepareCommand(MySqlCommand cmd, MySqlConnection conn, MySqlTransaction trans, CommandType cmdType, string cmdText, MySqlParameter[] cmdParms)
        {
            if (conn.State != ConnectionState.Open)
                conn.Open();

            cmd.Connection = conn;
            cmd.CommandText = cmdText;

            if (trans != null)
                cmd.Transaction = trans;

            cmd.CommandType = cmdType;

            if (cmdParms != null)
            {
                foreach (MySqlParameter parm in cmdParms)
                {
                    if (parm.Value == null)
                    {
                        parm.Value = DBNull.Value;
                    }
                    cmd.Parameters.Add(parm);
                }


            }
        }


        #endregion
    }
}
