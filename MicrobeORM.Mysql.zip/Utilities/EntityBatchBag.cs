﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace MicrobeORM.Mysql.Utilities
{
    /// <summary>
    /// 将实体  进行分批处理
    /// </summary>
    public static class EntityBatchBag
    {
        /// <summary>
        /// 单次执行查询 最多设置为40 条完整的SQL指令  ，因为SqlParametor最多能包含2100个参数
        /// 设置40条指令 ，一个实体就可以有2100/40=52个字段
        /// </summary>
        private  const int SingleBatchMaxSqlCount = 40;

        public static IList<IEnumerable<T>> SplitToBatchBag<T>(this IEnumerable<T> source) where T : BaseEntity
        {

            var container = new List<IEnumerable<T>>();

            var totalCount = source.Count();

            var pageSize = SingleBatchMaxSqlCount;

            var totalPages = totalCount / pageSize;

            if (totalPages == 0)
            {
                //不超过40条 直接返回原来的实体集合 不用分页
                container.Add(source);

                return container;
            }
            else
            {
                //超过1页 包含1页
                for (int pageIndex = 0; pageIndex <= totalPages; pageIndex++)
                {
                    var currentPageEntities = source.Skip(pageIndex * pageSize).Take(pageSize);
                    container.Add(currentPageEntities);
                }


            }

            return container;



        }
    }
}
