﻿using System;
using System.Linq.Expressions;

namespace MicrobeORM.Mysql.Utilities
{

    /// <summary>
    /// 表达式树的扩展
    /// </summary>
    public static class ExpressionExtensions
    {
        public static Expression AndAlso(this Expression left, Expression right)
        {
            return Expression.AndAlso(left, right);
        }
        public static Expression Call(this Expression instance, string methodName, params Expression[] arguments)
        {
            return Expression.Call(instance, instance.Type.GetMethod(methodName), arguments);
        }
        public static Expression Property(this Expression expression, string propertyName)
        {
            return Expression.Property(expression, propertyName);
        }
        public static Expression GreaterThan(this Expression left, Expression right)
        {
            return Expression.GreaterThan(left, right);
        }
        public static Expression<TDelegate> ToLambda<TDelegate>(this Expression body, params  ParameterExpression[] parameters)
        {
            return Expression.Lambda<TDelegate>(body, parameters);
        }

        ////***********下面是一个动态构建表达式树的例子*************************
        //        // Add the following using directive to your code file:
        //// using System.Linq.Expressions;

        //// Create an expression tree.
        //Expression<Func<int, bool>> exprTree = num => num < 5;

        //// Decompose the expression tree.
        //ParameterExpression param = (ParameterExpression)exprTree.Parameters[0];
        //BinaryExpression operation = (BinaryExpression)exprTree.Body;
        //ParameterExpression left = (ParameterExpression)operation.Left;
        //ConstantExpression right = (ConstantExpression)operation.Right;

        //Console.WriteLine("Decomposed expression: {0} => {1} {2} {3}",
        //                  param.Name, left.Name, operation.NodeType, right.Value);

        //// This code produces the following output:

        //// Decomposed expression: num => num LessThan 5   


    }
}
