﻿using System;
using System.Data.Common;

namespace MicrobeORM.Mysql.Utilities
{
    public static class MySqlDataReaderExtensions
    {
        /// <summary>
        /// 将IDataReader中的列 转化成指定的实体
        /// </summary>
        /// <typeparam name="TElemet"></typeparam>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static TElement ConvertDataReaderToEntity<TElement>(this DbDataReader dr)
            where TElement : BaseEntity,new()
        {


            if (dr.HasRows==false)
            {
                return default(TElement);
            }

                var model = new TElement();
                //1 获取实体中所有的属性Property  
                var propertys = model.GetCurrentEntityProperties();

                //2  判断属性类型 转化成对应 的数据类型  赋值
                foreach (var p in propertys)
                {

                    if (dr[p.Name] != null && dr[p.Name].ToString()!="")
                    {
                        var filedValue = dr[p.Name];
                        p.SetValue(model, filedValue, null);
                    }
                    else
                    {
                        p.SetValue(model, null, null);
                    }


                }

            
            //3 返回赋值的实体对象
            return model;
        }
    }
}
