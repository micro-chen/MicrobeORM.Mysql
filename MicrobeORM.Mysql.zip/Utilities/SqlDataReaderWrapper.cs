using System;
using System.Collections;
using System.Data;
using MySql.Data.MySqlClient;
using MySql.Data.Types;

using System.IO;
using System.Xml;

namespace MicrobeORM.Mysql.Utilities
{
  

    // <summary>
    // This is a wrapper for <see cref="MySqlDataReader" /> that allows a mock implementation to be used.
    // </summary>
    internal class MySqlDataReaderWrapper : MarshalByRefObject
    {
        private readonly MySqlDataReader _MySqlDataReader;

        protected MySqlDataReaderWrapper()
        {
        }

        public MySqlDataReaderWrapper(MySqlDataReader MySqlDataReader)
        {
            _MySqlDataReader = MySqlDataReader;
        }

        public virtual IDataReader GetData(int i)
        {
            return ((IDataRecord)_MySqlDataReader).GetData(i);
        }

        public virtual void Dispose()
        {
            _MySqlDataReader.Dispose();
        }


        public virtual void Close()
        {
            _MySqlDataReader.Close();
        }

        public virtual string GetDataTypeName(int i)
        {
            return _MySqlDataReader.GetDataTypeName(i);
        }

        public virtual IEnumerator GetEnumerator()
        {
            return _MySqlDataReader.GetEnumerator();
        }

        public virtual Type GetFieldType(int i)
        {
            return _MySqlDataReader.GetFieldType(i);
        }

        public virtual string GetName(int i)
        {
            return _MySqlDataReader.GetName(i);
        }

        public virtual Type GetProviderSpecificFieldType(int i)
        {
            return _MySqlDataReader.GetProviderSpecificFieldType(i);
        }

        public virtual int GetOrdinal(string name)
        {
            return _MySqlDataReader.GetOrdinal(name);
        }

        public virtual object GetProviderSpecificValue(int i)
        {
            return _MySqlDataReader.GetProviderSpecificValue(i);
        }

        public virtual int GetProviderSpecificValues(object[] values)
        {
            return _MySqlDataReader.GetProviderSpecificValues(values);
        }

        public virtual DataTable GetSchemaTable()
        {
            return _MySqlDataReader.GetSchemaTable();
        }

        public virtual bool GetBoolean(int i)
        {
            return _MySqlDataReader.GetBoolean(i);
        }


        public virtual byte GetByte(int i)
        {
            return _MySqlDataReader.GetByte(i);
        }

        public virtual long GetBytes(int i, long dataIndex, byte[] buffer, int bufferIndex, int length)
        {
            return _MySqlDataReader.GetBytes(i, dataIndex, buffer, bufferIndex, length);
        }


        public virtual char GetChar(int i)
        {
            return _MySqlDataReader.GetChar(i);
        }

        public virtual long GetChars(int i, long dataIndex, char[] buffer, int bufferIndex, int length)
        {
            return _MySqlDataReader.GetChars(i, dataIndex, buffer, bufferIndex, length);
        }

        public virtual DateTime GetDateTime(int i)
        {
            return _MySqlDataReader.GetDateTime(i);
        }

        public virtual decimal GetDecimal(int i)
        {
            return _MySqlDataReader.GetDecimal(i);
        }

        public virtual double GetDouble(int i)
        {
            return _MySqlDataReader.GetDouble(i);
        }

        public virtual float GetFloat(int i)
        {
            return _MySqlDataReader.GetFloat(i);
        }

        public virtual Guid GetGuid(int i)
        {
            return _MySqlDataReader.GetGuid(i);
        }

        public virtual short GetInt16(int i)
        {
            return _MySqlDataReader.GetInt16(i);
        }

        public virtual int GetInt32(int i)
        {
            return _MySqlDataReader.GetInt32(i);
        }

        public virtual long GetInt64(int i)
        {
            return _MySqlDataReader.GetInt64(i);
        }

        public virtual bool GetSqlBoolean(int i)
        {
            return _MySqlDataReader.GetBoolean(i);
        }


        public virtual byte GetSqlByte(int i)
        {
            return _MySqlDataReader.GetByte(i);
        }


        public virtual DateTime GetSqlDateTime(int i)
        {
            return _MySqlDataReader.GetDateTime(i);
        }

        public virtual decimal GetSqlDecimal(int i)
        {
            return _MySqlDataReader.GetDecimal(i);
        }

        public virtual Guid GetSqlGuid(int i)
        {
            return _MySqlDataReader.GetGuid(i);
        }

        public virtual double GetSqlDouble(int i)
        {
            return _MySqlDataReader.GetDouble(i);
        }

        public virtual short GetSqlInt16(int i)
        {
            return _MySqlDataReader.GetInt16(i);
        }

        public virtual int GetSqlInt32(int i)
        {
            return _MySqlDataReader.GetInt32(i);
        }

        public virtual long GetSqlInt64(int i)
        {
            return _MySqlDataReader.GetInt64(i);
        }


        public virtual float GetSqlSingle(int i)
        {
            return _MySqlDataReader.GetFloat(i);
        }

        public virtual string GetSqlString(int i)
        {
            return _MySqlDataReader.GetString(i);
        }



        public virtual object GetSqlValue(int i)
        {
            return _MySqlDataReader.GetValue(i);
        }

        public virtual int GetSqlValues(object[] values)
        {
            return _MySqlDataReader.GetValues(values);
        }

        public virtual string GetString(int i)
        {
            return _MySqlDataReader.GetString(i);
        }



        public virtual object GetValue(int i)
        {
            return _MySqlDataReader.GetValue(i);
        }

        public virtual TimeSpan GetTimeSpan(int i)
        {
            return _MySqlDataReader.GetTimeSpan(i);
        }

        public virtual MySqlDateTime GetDateTimeOffset(int i)
        {
            return _MySqlDataReader.GetMySqlDateTime(i);
        }

        public virtual int GetValues(object[] values)
        {
            return _MySqlDataReader.GetValues(values);
        }

        public virtual bool IsDBNull(int i)
        {
            return _MySqlDataReader.IsDBNull(i);
        }

        public virtual bool NextResult()
        {
            return _MySqlDataReader.NextResult();
        }

        public virtual bool Read()
        {
            return _MySqlDataReader.Read();
        }



        public virtual int Depth
        {
            get { return _MySqlDataReader.Depth; }
        }

        public virtual int FieldCount
        {
            get { return _MySqlDataReader.FieldCount; }
        }

        public virtual bool HasRows
        {
            get { return _MySqlDataReader.HasRows; }
        }

        public virtual bool IsClosed
        {
            get { return _MySqlDataReader.IsClosed; }
        }

        public virtual int RecordsAffected
        {
            get { return _MySqlDataReader.RecordsAffected; }
        }

        public virtual int VisibleFieldCount
        {
            get { return _MySqlDataReader.VisibleFieldCount; }
        }

        public virtual object this[int i]
        {
            get { return _MySqlDataReader[i]; }
        }

        public virtual object this[string name]
        {
            get { return _MySqlDataReader[name]; }
        }


    }
}