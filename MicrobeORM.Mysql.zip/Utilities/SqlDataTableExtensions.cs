﻿using System;
using System.Collections.Generic;
using System.Data;

namespace MicrobeORM.Mysql.Utilities
{
    public static class SqlDataTableExtensions
    {
        /// <summary>
        /// 将DataTable中的行 转化成指定的实体
        /// </summary>
        /// <typeparam name="TElemet"></typeparam>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static List<TElement> ConvertDataTableToEntitys<TElement>(this DataTable dt)
            where TElement : BaseEntity, new()
        {


            if (dt.Rows.Count <= 0)
            {
                return null;
            }
            var lstElemets = new List<TElement>();





            foreach (DataRow row in dt.Rows)
            {
                var model = new TElement();
                //1 获取实体中所有的属性Property  
                var propertys = model.GetCurrentEntityProperties();

                //2  判断属性类型 转化成对应 的数据类型  赋值
                foreach (var p in propertys)
                {
                    if (row[p.Name] != null && row[p.Name].ToString() != "")
                    {
                        var filedValue = row[p.Name];
                        p.SetValue(model, filedValue, null);
                    }
                    else
                    {
                        p.SetValue(model, null, null);
                    }


                }

                lstElemets.Add(model);
            }
            //3 返回赋值的集合
            return lstElemets;
        }
    }


}
